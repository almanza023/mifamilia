<?php return array (
  'busquedas.busquedas' => 'App\\Http\\Livewire\\Busquedas\\Busquedas',
  'consulta.consulta' => 'App\\Http\\Livewire\\Consulta\\Consulta',
  'focalizaciones.focalizaciones' => 'App\\Http\\Livewire\\Focalizaciones\\Focalizaciones',
  'historial.historial' => 'App\\Http\\Livewire\\Historial\\Historial',
  'home.home' => 'App\\Http\\Livewire\\Home\\Home',
  'perfil.perfil' => 'App\\Http\\Livewire\\Perfil\\Perfil',
  'profesionales.profesionales' => 'App\\Http\\Livewire\\Profesionales\\Profesionales',
  'seguimiento.seguimiento' => 'App\\Http\\Livewire\\Seguimiento\\Seguimiento',
);