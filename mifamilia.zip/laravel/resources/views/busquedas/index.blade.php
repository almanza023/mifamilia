@extends('theme.app')
@section('titulo')
    CONSULTAR BENEFICIARIOS VIGENCIA 2020
@endsection

@section('content')
<livewire:busquedas.busquedas />

@endsection




