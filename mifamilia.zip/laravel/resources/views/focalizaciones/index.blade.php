@extends('theme.app')
@section('titulo')
    FOCALIZACION VIGENCIA 2021
@endsection

@section('content')
<livewire:focalizaciones.focalizaciones />

@endsection




