@extends('theme.app')
@section('titulo')
    ESTADISTICAS HUELLAS 2021
@endsection

@section('content')
<livewire:consulta.consulta />

@endsection




