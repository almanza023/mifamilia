@extends('theme.app')
@section('titulo')
    HISTORIAL DE FOCALIZACION
@endsection

@section('content')
<livewire:historial.historial />

@endsection




