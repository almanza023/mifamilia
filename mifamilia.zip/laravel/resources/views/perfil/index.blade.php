@extends('theme.app')
@section('titulo')
    PERFIL
@endsection

@section('content')
<livewire:perfil.perfil />

@endsection




