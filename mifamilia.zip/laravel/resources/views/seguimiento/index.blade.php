@extends('theme.app')
@section('titulo')
    FORMATO DE SEGUIMIENTO
@endsection

@section('content')
<livewire:seguimiento.seguimiento />

@endsection




