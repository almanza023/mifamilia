<!-- jQuery  -->
<script src="{{ asset('theme/assets/js/jquery.min.js') }}"></script>
<script src="{{ asset('theme/assets/js/popper.min.js') }}"></script>
<script src="{{ asset('theme/assets/js/bootstrap.min.js') }}"></script>
<script src="{{ asset('theme/assets/js/modernizr.min.js') }}"></script>
<script src="{{ asset('theme/assets/js/detect.js') }}"></script>
<script src="{{ asset('theme/assets/js/fastclick.js') }}"></script>
<script src="{{ asset('theme/assets/js/jquery.slimscroll.js') }}"></script>
<script src="{{ asset('theme/assets/js/jquery.blockUI.js') }}"></script>
<script src="{{ asset('theme/assets/js/waves.js') }}"></script>
<script src="{{ asset('theme/assets/js/jquery.nicescroll.js') }}"></script>
<script src="{{ asset('theme/assets/js/jquery.scrollTo.min.js') }}"></script>
<script src="{{ asset('theme/assets/plugins/sweet-alert2/sweetalert2.min.js') }}"></script>

<!-- App js -->
<script src="{{ asset('theme/assets/js/app.js') }}"></script>
