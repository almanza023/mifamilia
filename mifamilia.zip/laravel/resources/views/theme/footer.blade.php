<footer class="footer">
    © 2021-2022 ORGANIZACIÓN TIEMPOS DE PAZ.
</footer>
