@extends('theme.app')
@section('titulo')
    ESPECIALIDADES
@endsection

@section('content')
<livewire:especialidades />

@endsection


