@extends('theme.app')
@section('content')
<livewire:home.home />
@endsection
