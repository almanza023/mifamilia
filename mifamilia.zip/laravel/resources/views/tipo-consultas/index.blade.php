@extends('theme.app')
@section('titulo')
    TIPO CONSULTAS
@endsection

@section('content')
<livewire:tipoconsultas />

@endsection


